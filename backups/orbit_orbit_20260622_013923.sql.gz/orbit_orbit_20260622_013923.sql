--
-- PostgreSQL database dump
--

\restrict O1JiZAIPfMaO3rbgxEWLx1c4QFnjU1vLahCTw5kwL9WmI3qr263AuLf1Dv2Y8TZ

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg12+1)
-- Dumped by pg_dump version 16.13 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY "public"."threads" DROP CONSTRAINT IF EXISTS "threads_created_by_fkey";
ALTER TABLE IF EXISTS ONLY "public"."subscriptions" DROP CONSTRAINT IF EXISTS "subscriptions_subscriber_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."subscriptions" DROP CONSTRAINT IF EXISTS "subscriptions_creator_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."stories" DROP CONSTRAINT IF EXISTS "stories_author_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."reports" DROP CONSTRAINT IF EXISTS "reports_reviewed_by_fkey";
ALTER TABLE IF EXISTS ONLY "public"."reports" DROP CONSTRAINT IF EXISTS "reports_reporter_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."reels" DROP CONSTRAINT IF EXISTS "reels_author_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."posts" DROP CONSTRAINT IF EXISTS "posts_author_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."notifications" DROP CONSTRAINT IF EXISTS "notifications_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."notifications" DROP CONSTRAINT IF EXISTS "notifications_actor_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."messages" DROP CONSTRAINT IF EXISTS "messages_thread_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."messages" DROP CONSTRAINT IF EXISTS "messages_sender_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."media" DROP CONSTRAINT IF EXISTS "media_owner_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."marketplace_listings" DROP CONSTRAINT IF EXISTS "marketplace_listings_seller_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."groups" DROP CONSTRAINT IF EXISTS "groups_created_by_fkey";
ALTER TABLE IF EXISTS ONLY "public"."group_members" DROP CONSTRAINT IF EXISTS "group_members_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."group_members" DROP CONSTRAINT IF EXISTS "group_members_group_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."follows" DROP CONSTRAINT IF EXISTS "follows_follower_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."follows" DROP CONSTRAINT IF EXISTS "follows_followee_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."events" DROP CONSTRAINT IF EXISTS "events_group_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."events" DROP CONSTRAINT IF EXISTS "events_creator_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ai_agent_state" DROP CONSTRAINT IF EXISTS "ai_agent_state_user_id_fkey";
DROP TRIGGER IF EXISTS "reels_search_vector_update" ON "public"."reels";
DROP TRIGGER IF EXISTS "posts_search_vector_trigger" ON "public"."posts";
DROP INDEX IF EXISTS "public"."idx_users_updated_at";
DROP INDEX IF EXISTS "public"."idx_users_status";
DROP INDEX IF EXISTS "public"."idx_users_metadata_gin";
DROP INDEX IF EXISTS "public"."idx_users_handle";
DROP INDEX IF EXISTS "public"."idx_users_domain";
DROP INDEX IF EXISTS "public"."idx_users_display_name_trgm";
DROP INDEX IF EXISTS "public"."idx_threads_participants";
DROP INDEX IF EXISTS "public"."idx_threads_last_message";
DROP INDEX IF EXISTS "public"."idx_threads_1to1";
DROP INDEX IF EXISTS "public"."idx_subs_creator";
DROP INDEX IF EXISTS "public"."idx_streams_expires";
DROP INDEX IF EXISTS "public"."idx_streams_channel";
DROP INDEX IF EXISTS "public"."idx_stories_expires";
DROP INDEX IF EXISTS "public"."idx_stories_created";
DROP INDEX IF EXISTS "public"."idx_reports_target";
DROP INDEX IF EXISTS "public"."idx_reports_status";
DROP INDEX IF EXISTS "public"."idx_reels_views";
DROP INDEX IF EXISTS "public"."idx_reels_search";
DROP INDEX IF EXISTS "public"."idx_reels_hashtags";
DROP INDEX IF EXISTS "public"."idx_reels_created";
DROP INDEX IF EXISTS "public"."idx_posts_search";
DROP INDEX IF EXISTS "public"."idx_posts_root";
DROP INDEX IF EXISTS "public"."idx_posts_pinned";
DROP INDEX IF EXISTS "public"."idx_posts_mentions";
DROP INDEX IF EXISTS "public"."idx_posts_hashtags";
DROP INDEX IF EXISTS "public"."idx_posts_group_created";
DROP INDEX IF EXISTS "public"."idx_posts_created_at";
DROP INDEX IF EXISTS "public"."idx_posts_author_created";
DROP INDEX IF EXISTS "public"."idx_notif_unread";
DROP INDEX IF EXISTS "public"."idx_notif_target";
DROP INDEX IF EXISTS "public"."idx_notif_actor";
DROP INDEX IF EXISTS "public"."idx_messages_thread_created";
DROP INDEX IF EXISTS "public"."idx_messages_sender";
DROP INDEX IF EXISTS "public"."idx_messages_created";
DROP INDEX IF EXISTS "public"."idx_media_type";
DROP INDEX IF EXISTS "public"."idx_media_cid";
DROP INDEX IF EXISTS "public"."idx_marketplace_status";
DROP INDEX IF EXISTS "public"."idx_marketplace_seller";
DROP INDEX IF EXISTS "public"."idx_marketplace_search";
DROP INDEX IF EXISTS "public"."idx_marketplace_geo";
DROP INDEX IF EXISTS "public"."idx_marketplace_category";
DROP INDEX IF EXISTS "public"."idx_groups_topics";
DROP INDEX IF EXISTS "public"."idx_groups_search";
DROP INDEX IF EXISTS "public"."idx_groups_member_count";
DROP INDEX IF EXISTS "public"."idx_group_members_user";
DROP INDEX IF EXISTS "public"."idx_group_members_role";
DROP INDEX IF EXISTS "public"."idx_follows_followee";
DROP INDEX IF EXISTS "public"."idx_follows_close_friends";
DROP INDEX IF EXISTS "public"."idx_events_starts";
DROP INDEX IF EXISTS "public"."idx_events_group";
DROP INDEX IF EXISTS "public"."idx_events_geo";
DROP INDEX IF EXISTS "public"."idx_embeddings_ann";
DROP INDEX IF EXISTS "public"."idx_cache_expires";
ALTER TABLE IF EXISTS ONLY "public"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "public"."users" DROP CONSTRAINT IF EXISTS "users_handle_key";
ALTER TABLE IF EXISTS ONLY "public"."threads" DROP CONSTRAINT IF EXISTS "threads_pkey";
ALTER TABLE IF EXISTS ONLY "public"."subscriptions" DROP CONSTRAINT IF EXISTS "subscriptions_pkey";
ALTER TABLE IF EXISTS ONLY "public"."stories" DROP CONSTRAINT IF EXISTS "stories_pkey";
ALTER TABLE IF EXISTS ONLY "public"."reports" DROP CONSTRAINT IF EXISTS "reports_pkey";
ALTER TABLE IF EXISTS ONLY "public"."reels" DROP CONSTRAINT IF EXISTS "reels_pkey";
ALTER TABLE IF EXISTS ONLY "public"."posts" DROP CONSTRAINT IF EXISTS "posts_pkey";
ALTER TABLE IF EXISTS ONLY "public"."orbit_streams" DROP CONSTRAINT IF EXISTS "orbit_streams_pkey";
ALTER TABLE IF EXISTS ONLY "public"."orbit_cache" DROP CONSTRAINT IF EXISTS "orbit_cache_pkey";
ALTER TABLE IF EXISTS ONLY "public"."notifications" DROP CONSTRAINT IF EXISTS "notifications_pkey";
ALTER TABLE IF EXISTS ONLY "public"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."media" DROP CONSTRAINT IF EXISTS "media_pkey";
ALTER TABLE IF EXISTS ONLY "public"."media" DROP CONSTRAINT IF EXISTS "media_cid_key";
ALTER TABLE IF EXISTS ONLY "public"."marketplace_listings" DROP CONSTRAINT IF EXISTS "marketplace_listings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."groups" DROP CONSTRAINT IF EXISTS "groups_slug_key";
ALTER TABLE IF EXISTS ONLY "public"."groups" DROP CONSTRAINT IF EXISTS "groups_pkey";
ALTER TABLE IF EXISTS ONLY "public"."group_members" DROP CONSTRAINT IF EXISTS "group_members_pkey";
ALTER TABLE IF EXISTS ONLY "public"."follows" DROP CONSTRAINT IF EXISTS "follows_pkey";
ALTER TABLE IF EXISTS ONLY "public"."events" DROP CONSTRAINT IF EXISTS "events_pkey";
ALTER TABLE IF EXISTS ONLY "public"."embeddings" DROP CONSTRAINT IF EXISTS "embeddings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ai_agent_state" DROP CONSTRAINT IF EXISTS "ai_agent_state_pkey";
ALTER TABLE IF EXISTS "public"."threads" ALTER COLUMN "thread_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."stories" ALTER COLUMN "story_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."reports" ALTER COLUMN "report_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."reels" ALTER COLUMN "reel_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."posts" ALTER COLUMN "post_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."orbit_streams" ALTER COLUMN "stream_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."notifications" ALTER COLUMN "notification_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."messages" ALTER COLUMN "message_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."media" ALTER COLUMN "media_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."marketplace_listings" ALTER COLUMN "listing_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."groups" ALTER COLUMN "group_id" DROP DEFAULT;
ALTER TABLE IF EXISTS "public"."events" ALTER COLUMN "event_id" DROP DEFAULT;
DROP TABLE IF EXISTS "public"."users";
DROP SEQUENCE IF EXISTS "public"."threads_thread_id_seq";
DROP TABLE IF EXISTS "public"."threads";
DROP TABLE IF EXISTS "public"."subscriptions";
DROP SEQUENCE IF EXISTS "public"."stories_story_id_seq";
DROP TABLE IF EXISTS "public"."stories";
DROP SEQUENCE IF EXISTS "public"."reports_report_id_seq";
DROP TABLE IF EXISTS "public"."reports";
DROP SEQUENCE IF EXISTS "public"."reels_reel_id_seq";
DROP TABLE IF EXISTS "public"."reels";
DROP SEQUENCE IF EXISTS "public"."posts_post_id_seq";
DROP TABLE IF EXISTS "public"."posts";
DROP SEQUENCE IF EXISTS "public"."orbit_streams_stream_id_seq";
DROP TABLE IF EXISTS "public"."orbit_streams";
DROP TABLE IF EXISTS "public"."orbit_cache";
DROP SEQUENCE IF EXISTS "public"."notifications_notification_id_seq";
DROP TABLE IF EXISTS "public"."notifications";
DROP SEQUENCE IF EXISTS "public"."messages_message_id_seq";
DROP TABLE IF EXISTS "public"."messages";
DROP SEQUENCE IF EXISTS "public"."media_media_id_seq";
DROP TABLE IF EXISTS "public"."media";
DROP SEQUENCE IF EXISTS "public"."marketplace_listings_listing_id_seq";
DROP TABLE IF EXISTS "public"."marketplace_listings";
DROP SEQUENCE IF EXISTS "public"."groups_group_id_seq";
DROP TABLE IF EXISTS "public"."groups";
DROP TABLE IF EXISTS "public"."group_members";
DROP TABLE IF EXISTS "public"."follows";
DROP SEQUENCE IF EXISTS "public"."events_event_id_seq";
DROP TABLE IF EXISTS "public"."events";
DROP TABLE IF EXISTS "public"."embeddings";
DROP TABLE IF EXISTS "public"."ai_agent_state";
DROP FUNCTION IF EXISTS "public"."reels_search_vector_update"();
DROP FUNCTION IF EXISTS "public"."posts_search_vector_update"();
DROP FUNCTION IF EXISTS "public"."cleanup_expired_cache"();
DROP TYPE IF EXISTS "public"."visibility";
DROP TYPE IF EXISTS "public"."user_status";
DROP TYPE IF EXISTS "public"."post_mode";
DROP TYPE IF EXISTS "public"."notification_type";
DROP TYPE IF EXISTS "public"."media_type";
DROP TYPE IF EXISTS "public"."group_role";
DROP TYPE IF EXISTS "public"."group_privacy";
DROP TYPE IF EXISTS "public"."condition_type";
DROP EXTENSION IF EXISTS "vector";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "postgis";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_trgm";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP EXTENSION IF EXISTS "btree_gin";
--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: btree_gin; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "btree_gin" WITH SCHEMA "public";


--
-- Name: EXTENSION "btree_gin"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "btree_gin" IS 'support for indexing common datatypes in GIN';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "public";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_trgm" WITH SCHEMA "public";


--
-- Name: EXTENSION "pg_trgm"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "pg_trgm" IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "public";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "postgis" WITH SCHEMA "public";


--
-- Name: EXTENSION "postgis"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "postgis" IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "public";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "vector" WITH SCHEMA "public";


--
-- Name: EXTENSION "vector"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "vector" IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: condition_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."condition_type" AS ENUM (
    'new',
    'like_new',
    'good',
    'fair'
);


--
-- Name: group_privacy; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."group_privacy" AS ENUM (
    'public',
    'private',
    'hidden'
);


--
-- Name: group_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."group_role" AS ENUM (
    'member',
    'mod',
    'admin',
    'owner'
);


--
-- Name: media_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."media_type" AS ENUM (
    'image',
    'video',
    'audio',
    'document'
);


--
-- Name: notification_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."notification_type" AS ENUM (
    'like',
    'comment',
    'follow',
    'mention',
    'ai',
    'event',
    'subscribe',
    'brand_deal'
);


--
-- Name: post_mode; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."post_mode" AS ENUM (
    'intimate',
    'public',
    'visual',
    'community'
);


--
-- Name: user_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."user_status" AS ENUM (
    'active',
    'suspended',
    'deleted',
    'verifying'
);


--
-- Name: visibility; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE "public"."visibility" AS ENUM (
    'public',
    'followers',
    'friends',
    'private',
    'group'
);


--
-- Name: cleanup_expired_cache(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."cleanup_expired_cache"() RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  DELETE FROM orbit_cache WHERE expires_at < NOW();
END;
$$;


--
-- Name: posts_search_vector_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."posts_search_vector_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.search_vector :=
    setweight(to_tsvector('simple', COALESCE(NEW.content_text, '')), 'A') ||
    setweight(to_tsvector('simple', array_to_string(NEW.hashtags, ' ')), 'B');
  RETURN NEW;
END;
$$;


--
-- Name: reels_search_vector_update(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION "public"."reels_search_vector_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.search_vector :=
    setweight(to_tsvector('simple', COALESCE(NEW.caption, '')), 'A') ||
    setweight(to_tsvector('simple', array_to_string(NEW.hashtags, ' ')), 'B');
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: ai_agent_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."ai_agent_state" (
    "user_id" "text" NOT NULL,
    "personality" "text" DEFAULT 'helpful'::"text",
    "autonomy_level" "text" DEFAULT 1,
    "enabled_features" "jsonb" DEFAULT '{}'::"jsonb",
    "long_term_memory" "jsonb" DEFAULT '{}'::"jsonb",
    "episodic_memory" "jsonb" DEFAULT '{}'::"jsonb",
    "context_window_size" integer DEFAULT 4096,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: embeddings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."embeddings" (
    "entity_type" smallint NOT NULL,
    "entity_id" bigint NOT NULL,
    "embedding" "public"."vector"(1536) NOT NULL,
    "model_version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."events" (
    "event_id" bigint NOT NULL,
    "group_id" bigint,
    "creator_id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "description" "text",
    "cover_cid" "text",
    "starts_at" timestamp with time zone NOT NULL,
    "ends_at" timestamp with time zone,
    "location_type" smallint,
    "location" "text",
    "location_geo" "public"."geography"(Point,4326),
    "rsvp_going" integer DEFAULT 0,
    "rsvp_interested" integer DEFAULT 0,
    "is_ticketed" boolean DEFAULT false,
    "ticket_price_cents" bigint,
    "currency" "text" DEFAULT 'INR'::"text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."events_event_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."events_event_id_seq" OWNED BY "public"."events"."event_id";


--
-- Name: follows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."follows" (
    "follower_id" "text" NOT NULL,
    "followee_id" "text" NOT NULL,
    "notify_level" smallint DEFAULT 0,
    "is_close_friend" boolean DEFAULT false,
    "is_blocked" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: group_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."group_members" (
    "group_id" bigint NOT NULL,
    "user_id" "text" NOT NULL,
    "role" "public"."group_role" DEFAULT 'member'::"public"."group_role" NOT NULL,
    "joined_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "muted_until" timestamp with time zone
);


--
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."groups" (
    "group_id" bigint NOT NULL,
    "slug" "text" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "cover_cid" "text",
    "icon_cid" "text",
    "privacy" "public"."group_privacy" DEFAULT 'public'::"public"."group_privacy" NOT NULL,
    "member_count" integer DEFAULT 1,
    "post_count" integer DEFAULT 0,
    "rules" "text",
    "topics" "text"[] DEFAULT '{}'::"text"[],
    "created_by" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "search_vector" "tsvector"
);


--
-- Name: groups_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."groups_group_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: groups_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."groups_group_id_seq" OWNED BY "public"."groups"."group_id";


--
-- Name: marketplace_listings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."marketplace_listings" (
    "listing_id" bigint NOT NULL,
    "seller_id" "text" NOT NULL,
    "title" "text" NOT NULL,
    "description" "text",
    "price_cents" bigint NOT NULL,
    "currency" "text" DEFAULT 'INR'::"text",
    "media_ids" bigint[] DEFAULT '{}'::bigint[],
    "category" "text",
    "item_condition" "public"."condition_type",
    "location_label" "text",
    "location_geo" "public"."geography"(Point,4326),
    "status" smallint DEFAULT 0,
    "view_count" integer DEFAULT 0,
    "search_vector" "tsvector",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: marketplace_listings_listing_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."marketplace_listings_listing_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: marketplace_listings_listing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."marketplace_listings_listing_id_seq" OWNED BY "public"."marketplace_listings"."listing_id";


--
-- Name: media; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."media" (
    "media_id" bigint NOT NULL,
    "owner_id" "text" NOT NULL,
    "cid" "text" NOT NULL,
    "media_type" "public"."media_type" NOT NULL,
    "storage_url" "text" NOT NULL,
    "cdn_url" "text" NOT NULL,
    "thumbnail_url" "text",
    "width" integer,
    "height" integer,
    "duration_ms" integer,
    "size_bytes" bigint,
    "mime_type" "text",
    "blurhash" "text",
    "hls_manifest" "text",
    "ai_tags" "jsonb" DEFAULT '{}'::"jsonb",
    "is_nsfw" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: media_media_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."media_media_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: media_media_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."media_media_id_seq" OWNED BY "public"."media"."media_id";


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."messages" (
    "message_id" bigint NOT NULL,
    "thread_id" bigint NOT NULL,
    "sender_id" "text" NOT NULL,
    "recipient_ids" "text"[] NOT NULL,
    "encrypted_payload" "bytea" NOT NULL,
    "content_type" smallint NOT NULL,
    "reply_to_id" bigint,
    "forwarded_from" bigint,
    "reactions" "jsonb" DEFAULT '{}'::"jsonb",
    "read_by" "jsonb" DEFAULT '{}'::"jsonb",
    "deleted_for" "text"[] DEFAULT '{}'::"text"[],
    "edited_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: messages_message_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."messages_message_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."messages_message_id_seq" OWNED BY "public"."messages"."message_id";


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."notifications" (
    "notification_id" bigint NOT NULL,
    "user_id" "text" NOT NULL,
    "actor_id" "text",
    "type" "public"."notification_type" NOT NULL,
    "target_type" smallint,
    "target_id" bigint,
    "payload" "jsonb" DEFAULT '{}'::"jsonb",
    "is_read" boolean DEFAULT false,
    "is_muted" boolean DEFAULT false,
    "ai_priority" smallint DEFAULT 50,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."notifications_notification_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."notifications_notification_id_seq" OWNED BY "public"."notifications"."notification_id";


--
-- Name: orbit_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."orbit_cache" (
    "cache_key" "text" NOT NULL,
    "cache_value" "jsonb" NOT NULL,
    "expires_at" timestamp with time zone,
    "ttl_seconds" integer,
    "hit_count" bigint DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: orbit_streams; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."orbit_streams" (
    "stream_id" bigint NOT NULL,
    "channel" "text" NOT NULL,
    "stream_key" "text",
    "payload" "jsonb" NOT NULL,
    "priority" smallint DEFAULT 50,
    "processed" boolean DEFAULT false,
    "processed_at" timestamp with time zone,
    "expires_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: orbit_streams_stream_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."orbit_streams_stream_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orbit_streams_stream_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."orbit_streams_stream_id_seq" OWNED BY "public"."orbit_streams"."stream_id";


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."posts" (
    "post_id" bigint NOT NULL,
    "author_id" "text" NOT NULL,
    "mode" "public"."post_mode" NOT NULL,
    "visibility" "public"."visibility" DEFAULT 'followers'::"public"."visibility" NOT NULL,
    "group_id" bigint,
    "parent_id" bigint,
    "root_id" bigint,
    "content_text" "text",
    "media_ids" bigint[] DEFAULT '{}'::bigint[],
    "media_count" smallint DEFAULT 0,
    "hashtags" "text"[] DEFAULT '{}'::"text"[],
    "mentions" "text"[] DEFAULT '{}'::"text"[],
    "language" "text" DEFAULT 'en'::"text",
    "like_count" bigint DEFAULT 0,
    "comment_count" bigint DEFAULT 0,
    "share_count" bigint DEFAULT 0,
    "view_count" bigint DEFAULT 0,
    "quote_count" bigint DEFAULT 0,
    "is_pinned" boolean DEFAULT false,
    "is_nsfw" boolean DEFAULT false,
    "is_sponsored" boolean DEFAULT false,
    "ai_moderation" "jsonb" DEFAULT '{}'::"jsonb",
    "search_vector" "tsvector",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "edited_at" timestamp with time zone,
    "deleted_at" timestamp with time zone
);


--
-- Name: posts_post_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."posts_post_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."posts_post_id_seq" OWNED BY "public"."posts"."post_id";


--
-- Name: reels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."reels" (
    "reel_id" bigint NOT NULL,
    "author_id" "text" NOT NULL,
    "media_id" "text" NOT NULL,
    "caption" "text",
    "audio_track_id" "text",
    "audio_start_ms" integer,
    "hashtags" "text"[] DEFAULT '{}'::"text"[],
    "duration_ms" integer NOT NULL,
    "thumbnail_cid" "text",
    "view_count" bigint DEFAULT 0,
    "like_count" bigint DEFAULT 0,
    "comment_count" bigint DEFAULT 0,
    "share_count" bigint DEFAULT 0,
    "save_count" bigint DEFAULT 0,
    "ai_topics" "jsonb" DEFAULT '{}'::"jsonb",
    "search_vector" "tsvector",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: reels_reel_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."reels_reel_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reels_reel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."reels_reel_id_seq" OWNED BY "public"."reels"."reel_id";


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."reports" (
    "report_id" bigint NOT NULL,
    "reporter_id" "text" NOT NULL,
    "target_type" smallint NOT NULL,
    "target_id" bigint NOT NULL,
    "reason" "text" NOT NULL,
    "description" "text",
    "status" smallint DEFAULT 0,
    "ai_classification" "jsonb" DEFAULT '{}'::"jsonb",
    "reviewed_by" "text",
    "reviewed_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: reports_report_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."reports_report_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reports_report_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."reports_report_id_seq" OWNED BY "public"."reports"."report_id";


--
-- Name: stories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."stories" (
    "story_id" bigint NOT NULL,
    "author_id" "text" NOT NULL,
    "media_id" "text" NOT NULL,
    "text_overlay" "text",
    "background_color" "text",
    "visibility" smallint DEFAULT 0 NOT NULL,
    "view_list" "text"[] DEFAULT '{}'::"text"[],
    "close_friends_only" boolean DEFAULT false,
    "ttl_seconds" integer DEFAULT 86400,
    "is_persistent" boolean DEFAULT false,
    "expires_at" timestamp with time zone NOT NULL,
    "view_count" integer DEFAULT 0,
    "reply_count" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: stories_story_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."stories_story_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stories_story_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."stories_story_id_seq" OWNED BY "public"."stories"."story_id";


--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."subscriptions" (
    "subscriber_id" "text" NOT NULL,
    "creator_id" "text" NOT NULL,
    "tier" smallint DEFAULT 1 NOT NULL,
    "price_cents" bigint NOT NULL,
    "currency" "text" DEFAULT 'INR'::"text",
    "started_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "renews_at" timestamp with time zone,
    "cancelled_at" timestamp with time zone,
    "is_active" boolean DEFAULT true
);


--
-- Name: threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."threads" (
    "thread_id" bigint NOT NULL,
    "thread_type" smallint NOT NULL,
    "participant_ids" "text"[] NOT NULL,
    "created_by" "text" NOT NULL,
    "name" "text",
    "icon_cid" "text",
    "encrypted_key" "bytea",
    "last_message_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_message_preview" "text",
    "unread_counts" "jsonb" DEFAULT '{}'::"jsonb",
    "muted_by" "jsonb" DEFAULT '{}'::"jsonb",
    "archived_by" "text"[] DEFAULT '{}'::"text"[],
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


--
-- Name: threads_thread_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE "public"."threads_thread_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: threads_thread_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE "public"."threads_thread_id_seq" OWNED BY "public"."threads"."thread_id";


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE "public"."users" (
    "did" "text" NOT NULL,
    "handle" "text" NOT NULL,
    "domain" "text",
    "display_name" "text" NOT NULL,
    "bio" "text",
    "avatar_cid" "text",
    "cover_cid" "text",
    "public_key" "bytea" NOT NULL,
    "identity_key" "bytea" NOT NULL,
    "signed_pre_key" "bytea" NOT NULL,
    "pre_keys" "bytea"[] DEFAULT '{}'::"bytea"[] NOT NULL,
    "pds_endpoint" "text" NOT NULL,
    "pds_public_key" "bytea",
    "reputation_score" numeric DEFAULT 100,
    "status" "public"."user_status" DEFAULT 'active'::"public"."user_status",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_seen_at" timestamp with time zone
);


--
-- Name: events event_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."events" ALTER COLUMN "event_id" SET DEFAULT "nextval"('"public"."events_event_id_seq"'::"regclass");


--
-- Name: groups group_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."groups" ALTER COLUMN "group_id" SET DEFAULT "nextval"('"public"."groups_group_id_seq"'::"regclass");


--
-- Name: marketplace_listings listing_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."marketplace_listings" ALTER COLUMN "listing_id" SET DEFAULT "nextval"('"public"."marketplace_listings_listing_id_seq"'::"regclass");


--
-- Name: media media_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."media" ALTER COLUMN "media_id" SET DEFAULT "nextval"('"public"."media_media_id_seq"'::"regclass");


--
-- Name: messages message_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."messages" ALTER COLUMN "message_id" SET DEFAULT "nextval"('"public"."messages_message_id_seq"'::"regclass");


--
-- Name: notifications notification_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."notifications" ALTER COLUMN "notification_id" SET DEFAULT "nextval"('"public"."notifications_notification_id_seq"'::"regclass");


--
-- Name: orbit_streams stream_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orbit_streams" ALTER COLUMN "stream_id" SET DEFAULT "nextval"('"public"."orbit_streams_stream_id_seq"'::"regclass");


--
-- Name: posts post_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."posts" ALTER COLUMN "post_id" SET DEFAULT "nextval"('"public"."posts_post_id_seq"'::"regclass");


--
-- Name: reels reel_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reels" ALTER COLUMN "reel_id" SET DEFAULT "nextval"('"public"."reels_reel_id_seq"'::"regclass");


--
-- Name: reports report_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reports" ALTER COLUMN "report_id" SET DEFAULT "nextval"('"public"."reports_report_id_seq"'::"regclass");


--
-- Name: stories story_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."stories" ALTER COLUMN "story_id" SET DEFAULT "nextval"('"public"."stories_story_id_seq"'::"regclass");


--
-- Name: threads thread_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."threads" ALTER COLUMN "thread_id" SET DEFAULT "nextval"('"public"."threads_thread_id_seq"'::"regclass");


--
-- Data for Name: ai_agent_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."ai_agent_state" ("user_id", "personality", "autonomy_level", "enabled_features", "long_term_memory", "episodic_memory", "context_window_size", "updated_at") FROM stdin;
did:orbit:3FxCHOAedU7vgA4nkJO6bA	helpful	suggest	{"dmSummary": true, "spamBlock": true, "feedFilter": true}	{}	{}	4096	2026-06-21 16:38:59.259392+00
did:orbit:x3i9Uo_xfqRo8SW0Dfqrfw	helpful	suggest	{"dmSummary": true, "spamBlock": true, "feedFilter": true}	{}	{}	4096	2026-06-21 16:39:46.553352+00
did:orbit:qz0XVo-Fv8xHzLjakDFOmg	helpful	suggest	{"dmSummary": true, "spamBlock": true, "feedFilter": true}	{}	{}	4096	2026-06-21 16:40:30.385872+00
did:orbit:FDvXpCq05uUb_GU-NGfYpQ	helpful	suggest	{"dmSummary": true, "spamBlock": true, "feedFilter": true}	{}	{}	4096	2026-06-21 20:09:22.512624+00
\.


--
-- Data for Name: embeddings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."embeddings" ("entity_type", "entity_id", "embedding", "model_version", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."events" ("event_id", "group_id", "creator_id", "title", "description", "cover_cid", "starts_at", "ends_at", "location_type", "location", "location_geo", "rsvp_going", "rsvp_interested", "is_ticketed", "ticket_price_cents", "currency", "created_at") FROM stdin;
\.


--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."follows" ("follower_id", "followee_id", "notify_level", "is_close_friend", "is_blocked", "created_at") FROM stdin;
did:orbit:YK5yqOv-GtDKyBjLFROuDg	did:orbit:D7cZB0nhrz8VRLK5mjmH7w	0	f	f	2026-06-21 16:24:29.26953+00
did:orbit:CalwNA3ktf2Tojoo9UhW2A	did:orbit:D7cZB0nhrz8VRLK5mjmH7w	0	f	f	2026-06-21 16:24:49.444269+00
did:orbit:CalwNA3ktf2Tojoo9UhW2A	did:orbit:Zs3_FjZIMcBddsLXhBrjbg	0	f	f	2026-06-21 16:24:49.459555+00
did:orbit:CalwNA3ktf2Tojoo9UhW2A	did:orbit:Mf658WgbECZNEp0XYDfnNA	0	f	f	2026-06-21 16:24:49.47514+00
did:orbit:qz0XVo-Fv8xHzLjakDFOmg	did:orbit:Vz84SICcvptxjrsW-XHmbA	0	f	f	2026-06-21 16:40:30.305195+00
did:orbit:NegjcirB01pMnLRw-yKBuw	did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	0	f	f	2026-06-21 17:10:29.404409+00
did:orbit:NegjcirB01pMnLRw-yKBuw	did:orbit:EBlHoJyllCnkfLnFbKqPpg	0	f	f	2026-06-21 17:10:29.421496+00
did:orbit:FDvXpCq05uUb_GU-NGfYpQ	did:orbit:NKhHWv-Vz5aVHB50pX-wuA	0	f	f	2026-06-21 20:09:22.442996+00
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."group_members" ("group_id", "user_id", "role", "joined_at", "muted_until") FROM stdin;
1	did:orbit:w2vptfyAbiERToL-yU91bA	owner	2026-06-21 16:37:17.545752+00	\N
2	did:orbit:qz0XVo-Fv8xHzLjakDFOmg	owner	2026-06-21 16:40:30.376515+00	\N
3	did:orbit:FDvXpCq05uUb_GU-NGfYpQ	owner	2026-06-21 20:09:22.504786+00	\N
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."groups" ("group_id", "slug", "name", "description", "cover_cid", "icon_cid", "privacy", "member_count", "post_count", "rules", "topics", "created_by", "created_at", "search_vector") FROM stdin;
1	test-grp	Test Group	Test	\N	\N	public	1	0	\N	{}	did:orbit:w2vptfyAbiERToL-yU91bA	2026-06-21 16:37:17.544239+00	\N
2	e2e-grp-1782060030	E2E Group 1782060030	\N	\N	\N	public	1	0	\N	{}	did:orbit:qz0XVo-Fv8xHzLjakDFOmg	2026-06-21 16:40:30.37547+00	\N
3	e2e-grp-1782072562	E2E Group 1782072562	\N	\N	\N	public	1	0	\N	{}	did:orbit:FDvXpCq05uUb_GU-NGfYpQ	2026-06-21 20:09:22.503914+00	\N
\.


--
-- Data for Name: marketplace_listings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."marketplace_listings" ("listing_id", "seller_id", "title", "description", "price_cents", "currency", "media_ids", "category", "item_condition", "location_label", "location_geo", "status", "view_count", "search_vector", "created_at") FROM stdin;
1	did:orbit:w2vptfyAbiERToL-yU91bA	Vintage leather jacket	Genuine leather, size M	4500	INR	{}	physical_product	good	Mumbai	\N	0	0	\N	2026-06-21 16:37:17.521523+00
2	did:orbit:qz0XVo-Fv8xHzLjakDFOmg	E2E test item	Test	1000	INR	{}	physical_product	\N	\N	\N	0	0	\N	2026-06-21 16:40:30.36094+00
3	did:orbit:FDvXpCq05uUb_GU-NGfYpQ	E2E test item	Test	1000	INR	{}	physical_product	\N	\N	\N	0	0	\N	2026-06-21 20:09:22.490192+00
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."media" ("media_id", "owner_id", "cid", "media_type", "storage_url", "cdn_url", "thumbnail_url", "width", "height", "duration_ms", "size_bytes", "mime_type", "blurhash", "hls_manifest", "ai_tags", "is_nsfw", "created_at") FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."messages" ("message_id", "thread_id", "sender_id", "recipient_ids", "encrypted_payload", "content_type", "reply_to_id", "forwarded_from", "reactions", "read_by", "deleted_for", "edited_at", "created_at") FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."notifications" ("notification_id", "user_id", "actor_id", "type", "target_type", "target_id", "payload", "is_read", "is_muted", "ai_priority", "created_at") FROM stdin;
\.


--
-- Data for Name: orbit_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."orbit_cache" ("cache_key", "cache_value", "expires_at", "ttl_seconds", "hit_count", "created_at", "updated_at") FROM stdin;
user:keys:did:orbit:Zs3_FjZIMcBddsLXhBrjbg	{"identityPrivateKey": "I2MUmNrtdQaOv+8vwsbqK9yO2+ZRaXfic5rVZgRoMHI=", "signedPreKeyPrivate": "xp69KuAXboWmGWbEuJbdzGxBZ/lMOOiQcR2uXk5h/iA="}	2026-06-28 16:15:51.405087+00	604800	0	2026-06-21 16:15:51.405087+00	2026-06-21 16:15:51.405087+00
user:keys:did:orbit:9fwAlmo4qj_Kv7wca5LCew	{"identityPrivateKey": "X0vQ2s499cDVrAT6MAmZhon3fBzXpaAMppsl1YXaaX8=", "signedPreKeyPrivate": "JgIaSXM0YC8i4iJp7WUOCUqGhzUEbBT4hVvtTjsEVGI="}	2026-06-28 16:16:30.470254+00	604800	0	2026-06-21 16:16:30.470254+00	2026-06-21 16:16:30.470254+00
user:keys:did:orbit:D7cZB0nhrz8VRLK5mjmH7w	{"identityPrivateKey": "JQRr7hu15UWSpxBPoeEBxR+RTmk2swlYLLb8lDIEuT0=", "signedPreKeyPrivate": "lro8hZAy7BJoNdjLpdtwPf2KF/Aab1UkksWq3qxAKiA="}	2026-06-28 16:16:45.289506+00	604800	0	2026-06-21 16:16:45.289506+00	2026-06-21 16:16:45.289506+00
user:keys:did:orbit:NWV371j3Lx_VR-zHypQmOQ	{"identityPrivateKey": "LkKp8nrzt/AxOhX3Gc2f94NXl5qyyw/pRBlfjj3K55o=", "signedPreKeyPrivate": "41M4dz2sCcUMl4vGZq6L7FTITSD2Es2Tasxo4YV6o2U="}	2026-06-28 16:16:57.35361+00	604800	0	2026-06-21 16:16:57.35361+00	2026-06-21 16:16:57.35361+00
user:keys:did:orbit:Mf658WgbECZNEp0XYDfnNA	{"identityPrivateKey": "kGlvrQIpAp73WXtN8rNNpNt/SIbzSZknuFrm6j8deBg=", "signedPreKeyPrivate": "x7gVLK3x76nZZ5WKbUd7JVqKoarIGIqvW2bTwI9nTjE="}	2026-06-28 16:17:08.850265+00	604800	0	2026-06-21 16:17:08.850265+00	2026-06-21 16:17:08.850265+00
user:keys:did:orbit:4BJblQFTNh0X3u7LY7ATpQ	{"identityPrivateKey": "hte47MyUrvMhUKIq3XaRkGeyuUpMahoU9w2MjLBmfaQ=", "signedPreKeyPrivate": "SQy97zsPRZR65Pq6eC+6HxzxKyMXg+kF1b3fPmKxT4Q="}	2026-06-28 16:17:20.009945+00	604800	0	2026-06-21 16:17:20.009945+00	2026-06-21 16:17:20.009945+00
user:keys:did:orbit:HcHExPyb5ReUd9ie43I_ZA	{"identityPrivateKey": "VV4AgwNqEu9vJKYLdRTCBVj3vtw8RIy4KZVcOufWGU4=", "signedPreKeyPrivate": "s0FALz8wtp6yvnGN/m2/T5Z76JWQugQnMBVGEG1uAHU="}	2026-06-28 16:23:16.450207+00	604800	0	2026-06-21 16:23:16.450207+00	2026-06-21 16:23:16.450207+00
user:keys:did:orbit:H7c8C4Dzs-jBJzuks1SWtw	{"identityPrivateKey": "xYBvgF55WiAVDTx3oE3cSQoLe5FEs+GTYhd62JnMzSY=", "signedPreKeyPrivate": "V5ypZeDAliggfOMe1VMAp3mCFjRJQ2M6NoSWib803AI="}	2026-06-28 16:23:32.652672+00	604800	0	2026-06-21 16:23:32.652672+00	2026-06-21 16:23:32.652672+00
user:keys:did:orbit:YK5yqOv-GtDKyBjLFROuDg	{"identityPrivateKey": "pUMkxuHrz2ev66NTIXXp4uWEYaiQ9IL+pvXxkq/I9GA=", "signedPreKeyPrivate": "5zghjjyfXCmKNn1nJLorN5T/arCiFzUABQx0pYkYZck="}	2026-06-28 16:24:29.252227+00	604800	0	2026-06-21 16:24:29.252227+00	2026-06-21 16:24:29.252227+00
user:keys:did:orbit:CalwNA3ktf2Tojoo9UhW2A	{"identityPrivateKey": "2iQLoGlViO7cfnhtByrzF0UE5Qa1+xUIaFNGLDdI+J8=", "signedPreKeyPrivate": "pvq+0wJn2Ki01OpVnqPt1xeveJj852JtRhdMehuSdZ0="}	2026-06-28 16:24:49.427807+00	604800	0	2026-06-21 16:24:49.427807+00	2026-06-21 16:24:49.427807+00
feed:chronological:did:orbit:CalwNA3ktf2Tojoo9UhW2A:all:latest	{"posts": [{"mode": "visual", "postId": "3", "groupId": null, "authorId": "did:orbit:Mf658WgbECZNEp0XYDfnNA", "hashtags": [], "isPinned": false, "language": "en", "mediaIds": [], "mentions": [], "createdAt": "2026-06-21T16:17:08.920Z", "likeCount": "0", "viewCount": "0", "mediaCount": 0, "shareCount": "0", "visibility": "public", "contentText": "Sunset in Goa", "authorHandle": "emma", "commentCount": "0", "authorAvatarCid": null, "authorDisplayName": "Emma"}, {"mode": "public", "postId": "2", "groupId": null, "authorId": "did:orbit:Mf658WgbECZNEp0XYDfnNA", "hashtags": [], "isPinned": false, "language": "en", "mediaIds": [], "mentions": [], "createdAt": "2026-06-21T16:17:08.910Z", "likeCount": "0", "viewCount": "0", "mediaCount": 0, "shareCount": "0", "visibility": "public", "contentText": "Just joined ORBIT! Excited to be here 🎉", "authorHandle": "emma", "commentCount": "0", "authorAvatarCid": null, "authorDisplayName": "Emma"}, {"mode": "public", "postId": "1", "groupId": null, "authorId": "did:orbit:D7cZB0nhrz8VRLK5mjmH7w", "hashtags": [], "isPinned": false, "language": "en", "mediaIds": [], "mentions": [], "createdAt": "2026-06-21T16:16:45.363Z", "likeCount": "0", "viewCount": "0", "mediaCount": 0, "shareCount": "0", "visibility": "public", "contentText": "Hello ORBIT!", "authorHandle": "carol", "commentCount": "0", "authorAvatarCid": null, "authorDisplayName": "Carol"}], "hasMore": false, "algorithm": "chronological"}	2026-06-21 16:25:19.492985+00	30	0	2026-06-21 16:24:49.492985+00	2026-06-21 16:24:49.492985+00
user:keys:did:orbit:eA-218OB79oSqqG7pCQDsA	{"identityPrivateKey": "k7eBJxOPJETC1pEMAMgeW9OvXwnWi6NtgGJbvoThAUQ=", "signedPreKeyPrivate": "0mSrswMyOOx7g1ulWxlmzRNtAOPy/l2mj0nGGmAVcrI="}	2026-06-28 16:28:03.82197+00	604800	0	2026-06-21 16:28:03.82197+00	2026-06-21 16:28:03.82197+00
user:keys:did:orbit:9MheNz7MoxclDQHhDUQE7g	{"identityPrivateKey": "50oa+kSRpC+4Kr8tASUt+R5VeOxSopUwJaWNCb5AVu0=", "signedPreKeyPrivate": "E7C116EnYj0B5ewvqaNaSVIejnNEBaIXDQISEraQyAo="}	2026-06-28 16:36:56.068549+00	604800	0	2026-06-21 16:36:56.068549+00	2026-06-21 16:36:56.068549+00
user:keys:did:orbit:B-9hFe4Qc407YvtHVaRM4w	{"identityPrivateKey": "fV6ehYR4tUNMY6IyiQXaIOkJTz0V2PegV5CVdfHZgQ4=", "signedPreKeyPrivate": "BBSduXbupr6jdA0xUEVYFSl2tb51ZAurlNo0sVM6hFI="}	2026-06-28 16:37:03.945516+00	604800	0	2026-06-21 16:37:03.945516+00	2026-06-21 16:37:03.945516+00
user:keys:did:orbit:w2vptfyAbiERToL-yU91bA	{"identityPrivateKey": "XW6tMhYlAK5nrJv/Qzal8847+96d+cz2+hCECZ0jtNM=", "signedPreKeyPrivate": "2IywKQoiFUdsuf6OjWFlJltULDwANZVOVyJkfWB9PBg="}	2026-06-28 16:37:17.461475+00	604800	0	2026-06-21 16:37:17.461475+00	2026-06-21 16:37:17.461475+00
user:keys:did:orbit:3FxCHOAedU7vgA4nkJO6bA	{"identityPrivateKey": "mgZssEXKTd8w2FeWF4fLbzbMB+adE8Cg9dRfFPxV/0U=", "signedPreKeyPrivate": "yUsdjNZK+KzS31K3qKtE1P3CEsLEvIB8CtzzkNj1sWI="}	2026-06-28 16:38:59.21516+00	604800	0	2026-06-21 16:38:59.21516+00	2026-06-21 16:38:59.21516+00
user:keys:did:orbit:5rCGPUHO5DEi4_OYowYDtQ	{"identityPrivateKey": "i+yL10lxZBzlv/+C9dhdQ+FJdUaM2bioYrdfxiltf7s=", "signedPreKeyPrivate": "Ap+cCAdux2WbKGmQKbWDKpStALWW2udqbQmfaeKCpl8="}	2026-06-28 16:39:08.369743+00	604800	0	2026-06-21 16:39:08.369743+00	2026-06-21 16:39:08.369743+00
user:keys:did:orbit:x3i9Uo_xfqRo8SW0Dfqrfw	{"identityPrivateKey": "N+wKXO6KGeL0A54ABNny5Xt1dVyJAf2hhZ7uuKMoma0=", "signedPreKeyPrivate": "bZh2tXdD877wLD9kxsUcK+CY/9mohmGRWvCeYkrY0A8="}	2026-06-28 16:39:46.456723+00	604800	0	2026-06-21 16:39:46.456723+00	2026-06-21 16:39:46.456723+00
user:keys:did:orbit:_CFq89RS0H1Tq-zmss_tZg	{"identityPrivateKey": "FRk848p7iV/okBnfEIoVxtwlrDcDjpULddJyv7VWUWw=", "signedPreKeyPrivate": "xr9twzVxfTexcsFiaznZqjL5J4LLMOZQr9ME36KY3/o="}	2026-06-28 16:40:21.715965+00	604800	0	2026-06-21 16:40:21.715965+00	2026-06-21 16:40:21.715965+00
user:keys:did:orbit:qz0XVo-Fv8xHzLjakDFOmg	{"identityPrivateKey": "1PyNxqhiRWRLcTBpeGnwPWAVGBWytRFY6UCdN8i+wN4=", "signedPreKeyPrivate": "E/ZHhWEx45jeqr+l1viVzi6yKDKtF0lsc2/yOCED978="}	2026-06-28 16:40:30.151275+00	604800	0	2026-06-21 16:40:30.151275+00	2026-06-21 16:40:30.151275+00
user:keys:did:orbit:Vz84SICcvptxjrsW-XHmbA	{"identityPrivateKey": "dUP3WIe7pJmcsImE/cRPPWRjNlfM8gxk/V9wV6rajrQ=", "signedPreKeyPrivate": "+Cyf40NGJAgwgQBQL8vpiwoWc/LnfEkfwPc4NUvpLIY="}	2026-06-28 16:40:30.274302+00	604800	0	2026-06-21 16:40:30.274302+00	2026-06-21 16:40:30.274302+00
feed:chronological:did:orbit:qz0XVo-Fv8xHzLjakDFOmg:all:latest	{"posts": [], "hasMore": false, "algorithm": "chronological"}	2026-06-21 16:41:00.321791+00	30	0	2026-06-21 16:40:30.321791+00	2026-06-21 16:40:30.321791+00
user:keys:did:orbit:RlcpjbRjNwyAFmJpxxP7zg	{"identityPrivateKey": "/rpeqct1GteeOG3DxFzJorQEooG6pyUD/I+kppCUsr8=", "signedPreKeyPrivate": "3zocS7wgxf6bUTDt8bKybqUJcwavVFmUrTV6UuFTOvM="}	2026-06-28 17:06:41.532797+00	604800	0	2026-06-21 17:06:41.532797+00	2026-06-21 17:06:41.532797+00
user:keys:did:orbit:NegjcirB01pMnLRw-yKBuw	{"identityPrivateKey": "QLzHvd77GO3FB7kBWcfCW+Dx/CmAxQlUFOT04doC6Lc=", "signedPreKeyPrivate": "zO4W4IRjDIMAAkqHmumOTrBGRaSkIupQXd526DSHK74="}	2026-06-28 17:10:28.129731+00	604800	0	2026-06-21 17:10:28.129731+00	2026-06-21 17:10:28.129731+00
user:keys:did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	{"identityPrivateKey": "RXh01HSvW86UR9TW8gZGLGKGyx0Q8zEduD2xwyzHNPc=", "signedPreKeyPrivate": "ABNEnxOTaMCxqFSN83tSQfNhtr97KFldkphHQOwRMDk="}	2026-06-28 17:10:28.137714+00	604800	0	2026-06-21 17:10:28.137714+00	2026-06-21 17:10:28.137714+00
user:keys:did:orbit:EBlHoJyllCnkfLnFbKqPpg	{"identityPrivateKey": "38B4RIPgCwI1Ovv3H/riZ0jrCgbUCUzPPHbZaDgu+j0=", "signedPreKeyPrivate": "+gi4hnorvLFDasq+lowoU6D9nCyu18yYaw6Yk2QD6wo="}	2026-06-28 17:10:28.143021+00	604800	0	2026-06-21 17:10:28.143021+00	2026-06-21 17:10:28.143021+00
user:keys:did:orbit:AJs4_YVPMJGHdJ4ei3lVPA	{"identityPrivateKey": "Wmv4KXCuXXRWucKP+KPWV+XhTOA6F0rGXVpnovQASxA=", "signedPreKeyPrivate": "Y/69mYa2r0g9Oz/RyT9TYXQpCAgaEbW5/uCvPZDNYJk="}	2026-06-28 17:12:02.384853+00	604800	0	2026-06-21 17:12:02.384853+00	2026-06-21 17:12:02.384853+00
user:keys:did:orbit:aqPQhIF-7kD5m24miWvzAA	{"identityPrivateKey": "cfMBO/QI5ecYSxt+jtXT5YVGHkie6XZFoIqTNyIECPw=", "signedPreKeyPrivate": "Ccz7pPIEmsNtZ3nFQYGn4HazFMf2VY8I0SJA4LcFC8w="}	2026-06-28 17:13:23.053704+00	604800	0	2026-06-21 17:13:23.053704+00	2026-06-21 17:13:23.053704+00
user:keys:did:orbit:k6iu5H6TWG_QsyHhQd2DPA	{"identityPrivateKey": "AEIHQynFBSQgJjEA3JuJAa+pGV12otvwo9KXgRWZJZY=", "signedPreKeyPrivate": "761ciWmHryb+VaNX/nZhoQAaYizBFsKTDonmq629BFk="}	2026-06-28 17:13:37.138148+00	604800	0	2026-06-21 17:13:37.138148+00	2026-06-21 17:13:37.138148+00
user:keys:did:orbit:MMFKhWkuds56_GxYncGr7w	{"identityPrivateKey": "68QcRdn4K0f0GadMANO6GRyPjdBAIc013klC77sv+20=", "signedPreKeyPrivate": "IlHR5v77W6qiHwS0x07wDJLb+XsNXa9cSNtH0/54mD4="}	2026-06-28 17:14:20.843436+00	604800	0	2026-06-21 17:14:20.843436+00	2026-06-21 17:14:20.843436+00
user:keys:did:orbit:xSbg_lpi3EqJNf0NjM-VKA	{"identityPrivateKey": "pPKkC342wa8RATvMhi91VRWjDGPMbcq432us3rYI3ks=", "signedPreKeyPrivate": "QT3AyVX0Xp8R1K3UgVH2jn7XIZON160YKgxtnqpr390="}	2026-06-28 17:14:58.79+00	604800	0	2026-06-21 17:14:58.79+00	2026-06-21 17:14:58.79+00
user:keys:did:orbit:FDvXpCq05uUb_GU-NGfYpQ	{"identityPrivateKey": "+lpQIr7m7iGMYAxQ52nbcRHM8X2574XoNA8VJXXk4nA=", "signedPreKeyPrivate": "+ujlnCR2cImkm8x0J7cilFslgnLJTB7fIvjJ8hy0oKU="}	2026-06-28 20:09:22.319579+00	604800	0	2026-06-21 20:09:22.319579+00	2026-06-21 20:09:22.319579+00
user:keys:did:orbit:NKhHWv-Vz5aVHB50pX-wuA	{"identityPrivateKey": "KThjXmco0WWZAGZ/9YbWnU6noo4JONbTgs15d7ZpIwI=", "signedPreKeyPrivate": "6fjWT7xemzRf/ac+vHtlMdXLOAvCSqBMPfU+f9y+yvQ="}	2026-06-28 20:09:22.414647+00	604800	0	2026-06-21 20:09:22.414647+00	2026-06-21 20:09:22.414647+00
feed:chronological:did:orbit:FDvXpCq05uUb_GU-NGfYpQ:all:latest	{"posts": [], "hasMore": false, "algorithm": "chronological"}	2026-06-21 20:09:52.45839+00	30	0	2026-06-21 20:09:22.45839+00	2026-06-21 20:09:22.45839+00
\.


--
-- Data for Name: orbit_streams; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."orbit_streams" ("stream_id", "channel", "stream_key", "payload", "priority", "processed", "processed_at", "expires_at", "created_at") FROM stdin;
1	post.created:did:orbit:D7cZB0nhrz8VRLK5mjmH7w	\N	{"mode": "public", "postId": "1"}	50	f	\N	2026-06-21 17:16:45.367705+00	2026-06-21 16:16:45.367705+00
2	post.created:did:orbit:Mf658WgbECZNEp0XYDfnNA	\N	{"mode": "public", "postId": "2"}	50	f	\N	2026-06-21 17:17:08.911441+00	2026-06-21 16:17:08.911441+00
3	post.created:did:orbit:Mf658WgbECZNEp0XYDfnNA	\N	{"mode": "visual", "postId": "3"}	50	f	\N	2026-06-21 17:17:08.921846+00	2026-06-21 16:17:08.921846+00
4	post.created:did:orbit:eA-218OB79oSqqG7pCQDsA	\N	{"mode": "public", "postId": "4"}	50	f	\N	2026-06-21 17:28:03.861324+00	2026-06-21 16:28:03.861324+00
5	notification.new:did:orbit:D7cZB0nhrz8VRLK5mjmH7w	\N	{"type": "like", "actorId": "did:orbit:w2vptfyAbiERToL-yU91bA", "targetId": "1", "targetType": "post"}	50	f	\N	2026-06-21 17:37:17.510916+00	2026-06-21 16:37:17.510916+00
6	post.created:did:orbit:qz0XVo-Fv8xHzLjakDFOmg	\N	{"mode": "public", "postId": "5"}	50	f	\N	2026-06-21 17:40:30.252889+00	2026-06-21 16:40:30.252889+00
7	notification.new:did:orbit:qz0XVo-Fv8xHzLjakDFOmg	\N	{"type": "like", "actorId": "did:orbit:qz0XVo-Fv8xHzLjakDFOmg", "targetId": "1", "targetType": "post"}	50	f	\N	2026-06-21 17:40:30.263456+00	2026-06-21 16:40:30.263456+00
8	post.created:did:orbit:NegjcirB01pMnLRw-yKBuw	\N	{"mode": "public", "postId": "6"}	50	f	\N	2026-06-21 18:10:28.149566+00	2026-06-21 17:10:28.149566+00
9	post.created:did:orbit:NegjcirB01pMnLRw-yKBuw	\N	{"mode": "visual", "postId": "7"}	50	f	\N	2026-06-21 18:10:28.154246+00	2026-06-21 17:10:28.154246+00
10	post.created:did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	\N	{"mode": "public", "postId": "8"}	50	f	\N	2026-06-21 18:10:28.157936+00	2026-06-21 17:10:28.157936+00
11	post.created:did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	\N	{"mode": "intimate", "postId": "9"}	50	f	\N	2026-06-21 18:10:28.161177+00	2026-06-21 17:10:28.161177+00
12	post.created:did:orbit:EBlHoJyllCnkfLnFbKqPpg	\N	{"mode": "public", "postId": "10"}	50	f	\N	2026-06-21 18:10:28.164648+00	2026-06-21 17:10:28.164648+00
13	post.created:did:orbit:EBlHoJyllCnkfLnFbKqPpg	\N	{"mode": "community", "postId": "11"}	50	f	\N	2026-06-21 18:10:28.167589+00	2026-06-21 17:10:28.167589+00
14	post.created:did:orbit:MMFKhWkuds56_GxYncGr7w	\N	{"mode": "public", "postId": "12"}	50	f	\N	2026-06-21 18:14:20.851047+00	2026-06-21 17:14:20.851047+00
15	post.created:did:orbit:MMFKhWkuds56_GxYncGr7w	\N	{"mode": "visual", "postId": "13"}	50	f	\N	2026-06-21 18:14:20.855545+00	2026-06-21 17:14:20.855545+00
16	post.created:did:orbit:FDvXpCq05uUb_GU-NGfYpQ	\N	{"mode": "public", "postId": "14"}	50	f	\N	2026-06-21 21:09:22.396937+00	2026-06-21 20:09:22.396937+00
17	notification.new:did:orbit:FDvXpCq05uUb_GU-NGfYpQ	\N	{"type": "like", "actorId": "did:orbit:FDvXpCq05uUb_GU-NGfYpQ", "targetId": "1", "targetType": "post"}	50	f	\N	2026-06-21 21:09:22.405515+00	2026-06-21 20:09:22.405515+00
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."posts" ("post_id", "author_id", "mode", "visibility", "group_id", "parent_id", "root_id", "content_text", "media_ids", "media_count", "hashtags", "mentions", "language", "like_count", "comment_count", "share_count", "view_count", "quote_count", "is_pinned", "is_nsfw", "is_sponsored", "ai_moderation", "search_vector", "created_at", "edited_at", "deleted_at") FROM stdin;
2	did:orbit:Mf658WgbECZNEp0XYDfnNA	public	public	\N	\N	\N	Just joined ORBIT! Excited to be here 🎉	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'be':6A 'excited':4A 'here':7A 'joined':2A 'just':1A 'orbit':3A 'to':5A	2026-06-21 16:17:08.910376+00	\N	\N
3	did:orbit:Mf658WgbECZNEp0XYDfnNA	visual	public	\N	\N	\N	Sunset in Goa	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'goa':3A 'in':2A 'sunset':1A	2026-06-21 16:17:08.920541+00	\N	\N
4	did:orbit:eA-218OB79oSqqG7pCQDsA	public	public	\N	\N	\N	Hello from Jack! ORBIT is amazing	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'amazing':6A 'from':2A 'hello':1A 'is':5A 'jack':3A 'orbit':4A	2026-06-21 16:28:03.857921+00	\N	\N
1	did:orbit:D7cZB0nhrz8VRLK5mjmH7w	public	public	\N	\N	\N	Hello ORBIT!	{}	0	{}	{}	en	1	0	0	0	0	f	f	f	{}	'hello':1A 'orbit':2A	2026-06-21 16:16:45.363658+00	\N	\N
5	did:orbit:qz0XVo-Fv8xHzLjakDFOmg	public	public	\N	\N	\N	E2E smoke test post	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'e2e':1A 'post':4A 'smoke':2A 'test':3A	2026-06-21 16:40:30.250749+00	\N	\N
6	did:orbit:NegjcirB01pMnLRw-yKBuw	public	public	\N	\N	\N	Just joined ORBIT! 🚀 The interface is so calm and minimal — love it. #firstpost	{}	0	{firstpost}	{}	en	0	0	0	0	0	f	f	f	{}	'and':9A 'calm':8A 'firstpost':13A,14B 'interface':5A 'is':6A 'it':12A 'joined':2A 'just':1A 'love':11A 'minimal':10A 'orbit':3A 'so':7A 'the':4A	2026-06-21 17:10:28.147343+00	\N	\N
7	did:orbit:NegjcirB01pMnLRw-yKBuw	visual	public	\N	\N	\N	Sunset from my window tonight 🌅	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'from':2A 'my':3A 'sunset':1A 'tonight':5A 'window':4A	2026-06-21 17:10:28.153193+00	\N	\N
8	did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	public	public	\N	\N	\N	Working on a distributed database at Vedadb. Anyone else into pgvector + postgis?	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'a':3A 'anyone':8A 'at':6A 'database':5A 'distributed':4A 'else':9A 'into':10A 'on':2A 'pgvector':11A 'postgis':12A 'vedadb':7A 'working':1A	2026-06-21 17:10:28.15727+00	\N	\N
9	did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	intimate	public	\N	\N	\N	Coffee + code = happiness ☕💻	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'code':2A 'coffee':1A 'happiness':3A	2026-06-21 17:10:28.160302+00	\N	\N
10	did:orbit:EBlHoJyllCnkfLnFbKqPpg	public	public	\N	\N	\N	Reading "Designing Data-Intensive Applications" for the third time. Each time I learn something new.	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'applications':6A 'data':4A 'data-intensive':3A 'designing':2A 'each':11A 'for':7A 'i':13A 'intensive':5A 'learn':14A 'new':16A 'reading':1A 'something':15A 'the':8A 'third':9A 'time':10A,12A	2026-06-21 17:10:28.163944+00	\N	\N
11	did:orbit:EBlHoJyllCnkfLnFbKqPpg	community	public	\N	\N	\N	Made paneer tikka from scratch today! Recipe in comments 👇	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'comments':9A 'from':4A 'in':8A 'made':1A 'paneer':2A 'recipe':7A 'scratch':5A 'tikka':3A 'today':6A	2026-06-21 17:10:28.166952+00	\N	\N
12	did:orbit:MMFKhWkuds56_GxYncGr7w	public	public	\N	\N	\N	My first post on ORBIT! 🎉	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'first':2A 'my':1A 'on':4A 'orbit':5A 'post':3A	2026-06-21 17:14:20.848933+00	\N	\N
13	did:orbit:MMFKhWkuds56_GxYncGr7w	visual	public	\N	\N	\N	Coffee + sunrise = best combo	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'best':3A 'coffee':1A 'combo':4A 'sunrise':2A	2026-06-21 17:14:20.8545+00	\N	\N
14	did:orbit:FDvXpCq05uUb_GU-NGfYpQ	public	public	\N	\N	\N	E2E smoke test post	{}	0	{}	{}	en	0	0	0	0	0	f	f	f	{}	'e2e':1A 'post':4A 'smoke':2A 'test':3A	2026-06-21 20:09:22.394001+00	\N	\N
\.


--
-- Data for Name: reels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."reels" ("reel_id", "author_id", "media_id", "caption", "audio_track_id", "audio_start_ms", "hashtags", "duration_ms", "thumbnail_cid", "view_count", "like_count", "comment_count", "share_count", "save_count", "ai_topics", "search_vector", "created_at") FROM stdin;
3	did:orbit:5rCGPUHO5DEi4_OYowYDtQ	video-test-2	Test reel	\N	\N	{#test}	15000	\N	0	0	0	0	0	{}	'reel':2A 'test':1A,3B	2026-06-21 16:39:08.390906+00
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."reports" ("report_id", "reporter_id", "target_type", "target_id", "reason", "description", "status", "ai_classification", "reviewed_by", "reviewed_at", "created_at") FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."spatial_ref_sys" ("srid", "auth_name", "auth_srid", "srtext", "proj4text") FROM stdin;
\.


--
-- Data for Name: stories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."stories" ("story_id", "author_id", "media_id", "text_overlay", "background_color", "visibility", "view_list", "close_friends_only", "ttl_seconds", "is_persistent", "expires_at", "view_count", "reply_count", "created_at") FROM stdin;
1	did:orbit:3FxCHOAedU7vgA4nkJO6bA	media-test-1	\N	\N	0	{}	f	86400	f	2026-06-22 16:38:59.122+00	0	0	2026-06-21 16:38:59.231859+00
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."subscriptions" ("subscriber_id", "creator_id", "tier", "price_cents", "currency", "started_at", "renews_at", "cancelled_at", "is_active") FROM stdin;
\.


--
-- Data for Name: threads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."threads" ("thread_id", "thread_type", "participant_ids", "created_by", "name", "icon_cid", "encrypted_key", "last_message_at", "last_message_preview", "unread_counts", "muted_by", "archived_by", "created_at") FROM stdin;
1	0	{did:orbit:w2vptfyAbiERToL-yU91bA,NULL}	did:orbit:w2vptfyAbiERToL-yU91bA	\N	\N	\N	2026-06-21 16:37:17.557619+00	\N	{}	{}	{}	2026-06-21 16:37:17.557619+00
2	0	{did:orbit:qz0XVo-Fv8xHzLjakDFOmg,NULL}	did:orbit:qz0XVo-Fv8xHzLjakDFOmg	\N	\N	\N	2026-06-21 16:40:30.351872+00	\N	{}	{}	{}	2026-06-21 16:40:30.351872+00
3	0	{did:orbit:FDvXpCq05uUb_GU-NGfYpQ,NULL}	did:orbit:FDvXpCq05uUb_GU-NGfYpQ	\N	\N	\N	2026-06-21 20:09:22.482865+00	\N	{}	{}	{}	2026-06-21 20:09:22.482865+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY "public"."users" ("did", "handle", "domain", "display_name", "bio", "avatar_cid", "cover_cid", "public_key", "identity_key", "signed_pre_key", "pre_keys", "pds_endpoint", "pds_public_key", "reputation_score", "status", "metadata", "created_at", "updated_at", "last_seen_at") FROM stdin;
did:orbit:Zs3_FjZIMcBddsLXhBrjbg	alice	\N	Alice	\N	\N	\N	\\x6233356d313435492f44435934764c4f5051665339717565577a574f5a67764a446c346c6239636b7a76633d	\\x544355437134554a6f4f4355353675427a6d376a46565762762f5a4c7536736942516149316c3278456d453d	\\x787036394b754158626f576d47576245754a62647a4778425a2f6c4d4f4f695163523275586b35682f69413d	{}	https://pds.orbit.com/did:orbit:Zs3_FjZIMcBddsLXhBrjbg	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:15:51.401996+00	2026-06-21 16:15:51.401996+00	\N
did:orbit:9fwAlmo4qj_Kv7wca5LCew	bob	\N	Bob	\N	\N	\N	\\x6d4347704a73315a413352796339444561544e515673326337454955586d6334516b6d7368504a473675733d	\\x49365978635552526247325278684c614d506c56376c3278796d506853554d47706f434f79596c626945413d	\\x4a67496153584d305943386934694a703757554f43557147687a55456242543468567674546a73455647493d	{}	http://localhost:3001/did:orbit:9fwAlmo4qj_Kv7wca5LCew	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:16:30.468169+00	2026-06-21 16:16:30.468169+00	\N
did:orbit:D7cZB0nhrz8VRLK5mjmH7w	carol	\N	Carol	\N	\N	\N	\\x4e2f307a535471376934374a72533370445062334678324f5752643978444f2b724b4d5465305230452f493d	\\x573768356f44756d7178396a6a6f676865797a3537593438663253582f4c7677617a6b7341496b525357773d	\\x6c726f38685a417937424a6f4e646a4c706474775066324b462f41616231556b6b735771337178414b69413d	{}	http://localhost:3001/did:orbit:D7cZB0nhrz8VRLK5mjmH7w	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:16:45.288222+00	2026-06-21 16:16:45.288222+00	\N
did:orbit:NWV371j3Lx_VR-zHypQmOQ	dave	\N	Dave	\N	\N	\N	\\x533652586c61424c787630424e305a6c547638676d6e4b755343364f6b56314b67445762646b752f5a33553d	\\x7461594a335a6d37324a324254497833636a3363522f77516a70373869586343627849556f6b52635248513d	\\x34314d34647a32734363554d6c3476475a71364c3746544954534432457332546173786f345956366f32553d	{}	http://localhost:3001/did:orbit:NWV371j3Lx_VR-zHypQmOQ	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:16:57.351938+00	2026-06-21 16:16:57.351938+00	\N
did:orbit:Mf658WgbECZNEp0XYDfnNA	emma	\N	Emma	\N	\N	\N	\\x6d6d44662f696d45346c6d4a6d2b727049497538504c6b4838414d6b65307564484c6b78634352345752633d	\\x5a57623162373246787630386c3269702f61727570366e785a704764423344644f33623179552f306643303d	\\x783767564c4b337837366e5a5a35574b625564374a56714b6f61724947497176573262547749396e546a453d	{}	http://localhost:3001/did:orbit:Mf658WgbECZNEp0XYDfnNA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:17:08.849476+00	2026-06-21 16:17:08.849476+00	\N
did:orbit:4BJblQFTNh0X3u7LY7ATpQ	emma2	\N	Emma2	\N	\N	\N	\\x564b6d32716a596a503536526e716f44656e4a6c2f71356a565368354e65482f694c3075562b45737370383d	\\x4c6d61767944443743354f2f6a2f67622b7961496f2b6b396371417963686356776143667246424d6f306b3d	\\x53517939377a7350525a52363550713665432b3648787a784b794d58672b6b4631623366506d4b785434513d	{}	http://localhost:3001/did:orbit:4BJblQFTNh0X3u7LY7ATpQ	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:17:20.008784+00	2026-06-21 16:17:20.008784+00	\N
did:orbit:HcHExPyb5ReUd9ie43I_ZA	frank	\N	Frank	\N	\N	\N	\\x3642354331746b61786a466a6e514461562b64337159524a4a424e384631666e544545454859395a4a4f303d	\\x64766b456d72434a576178584f79724c517763306d7874347858556a4e6c456b6c74704a745a4a4e386c453d	\\x733046414c7a387774703679766e474e2f6d322f54355a37364a57517567516e4d425647454731754148553d	{}	http://localhost:3001/did:orbit:HcHExPyb5ReUd9ie43I_ZA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:23:16.44816+00	2026-06-21 16:23:16.44816+00	\N
did:orbit:H7c8C4Dzs-jBJzuks1SWtw	grace	\N	Grace	\N	\N	\N	\\x30742b716e6f535250346c765964316a3832435378495357466f5375483066436e745030336a6c676f39673d	\\x45704339464b46392f34714442774e697379687644462f313177632f416e514750497468716933596e6a6f3d	\\x563579705a6544416c696767664f4d6531564d4170336d43466a524a51324d364e6f5357696238303341493d	{}	http://localhost:3001/did:orbit:H7c8C4Dzs-jBJzuks1SWtw	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:23:32.651942+00	2026-06-21 16:23:32.651942+00	\N
did:orbit:YK5yqOv-GtDKyBjLFROuDg	henry	\N	Henry	\N	\N	\N	\\x717051494d4671376172706543376d4639364e34767a6e78572b455665415a49304e657653326a667641733d	\\x4d314b544f4c4e6566716c517639564b4438307438465335535531443773636831394d424c73594869446b3d	\\x357a67686a6a796658436d4b4e6e316e4a4c6f724e35542f61724369467a55414251783070596b595a636b3d	{}	http://localhost:3001/did:orbit:YK5yqOv-GtDKyBjLFROuDg	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:24:29.250036+00	2026-06-21 16:24:29.250036+00	\N
did:orbit:CalwNA3ktf2Tojoo9UhW2A	ivy	\N	Ivy	\N	\N	\N	\\x5330444b37754a31346c786b2b52427456352f65745251444c6a746c4735435530324347507230387751553d	\\x722b434f6153684e6749665955724965536e323731795533673565676d44426766586851465245636346303d	\\x7076712b30774a6e324b6930314f70566e71507431786576654a6a3835324a745268644d65687553645a303d	{}	http://localhost:3001/did:orbit:CalwNA3ktf2Tojoo9UhW2A	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:24:49.426743+00	2026-06-21 16:24:49.426743+00	\N
did:orbit:eA-218OB79oSqqG7pCQDsA	jack	\N	Jack	\N	\N	\N	\\x2f7873485836674b316d412b5875324548504e7654617a3258716e423472773977674531487134707a76513d	\\x5049426b66762f526f525a336b3149337248324c484e7a353958784a326e6b496b546c6c477951682f46493d	\\x306d537273774d794f4f78376731756c57786c6d7a524e74414f50792f6c326d6a306e47476d41566372493d	{}	http://localhost:3001/did:orbit:eA-218OB79oSqqG7pCQDsA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:28:03.819893+00	2026-06-21 16:28:03.819893+00	\N
did:orbit:9MheNz7MoxclDQHhDUQE7g	alice_qa	\N	Alice QA	\N	\N	\N	\\x445079446e2b586f66436c4a6f4a427765434338693279315558366867674a3434715779707946494e50733d	\\x367a49655a79614e62534145336f7a753175527431333148706d61706534674a68527637627876357253633d	\\x453743313136456e596a30423565777671614e61535649656a6e4e4542614958445149534572615179416f3d	{}	http://localhost:3001/did:orbit:9MheNz7MoxclDQHhDUQE7g	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:36:56.065509+00	2026-06-21 16:36:56.065509+00	\N
did:orbit:B-9hFe4Qc407YvtHVaRM4w	alice_qa2	\N	Alice QA2	\N	\N	\N	\\x3265724d704236334d734170673769416f444c4530396c427843443853756b3733313669735a375276484d3d	\\x4a455672656a654e5033737636734b33764379434874414b656d536a536a7a7a382b3032644947506c536f3d	\\x42425364755862757072366a644130785545565946536c32746235315a4175726c4e6f3073564d366846493d	{}	http://localhost:3001/did:orbit:B-9hFe4Qc407YvtHVaRM4w	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:37:03.944296+00	2026-06-21 16:37:03.944296+00	\N
did:orbit:w2vptfyAbiERToL-yU91bA	alice_qa3	\N	Alice QA3	\N	\N	\N	\\x374b724164487443452f5468524c2b7a38734d77676d516c31526b4f79366a4e573938564d626b415359673d	\\x57716a41395237762b446e6d363956366436742b64486661633550794e7577662b6c576b385147635831593d	\\x324979774b516f69465564737566364f6a57466c4a6c74554c4477414e5a564f56794a6b665742395042673d	{}	http://localhost:3001/did:orbit:w2vptfyAbiERToL-yU91bA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:37:17.459644+00	2026-06-21 16:37:17.459644+00	\N
did:orbit:3FxCHOAedU7vgA4nkJO6bA	qa_recheck	\N	QA Recheck	\N	\N	\N	\\x5441536e56426a6852415467775a324758556c3670317a556a3237337479545258727275744f2f42764f383d	\\x647379426e6c4862484f37374946574370353038694c32486a77506442664c30474b6a4b6c3858343947453d	\\x795573646a4e5a4b2b4b7a5333314b33714b74453150334345734c457649423843747a7a6b4e6a317357493d	{}	http://localhost:3001/did:orbit:3FxCHOAedU7vgA4nkJO6bA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:38:59.213215+00	2026-06-21 16:38:59.213215+00	\N
did:orbit:5rCGPUHO5DEi4_OYowYDtQ	qa_recheck2	\N	QA Recheck2	\N	\N	\N	\\x6156386835483878494c6b7044513234624c3534356b736c3535716764497875675037394f6433717061303d	\\x5061654430474b7961536c534f4e5a6f696b6b6239465952737a353550335833566a6879377358644167593d	\\x41702b6343416475783257624b476d514b6257444b705374414c57573275647162516d6661654b43706c383d	{}	http://localhost:3001/did:orbit:5rCGPUHO5DEi4_OYowYDtQ	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:39:08.36811+00	2026-06-21 16:39:08.36811+00	\N
did:orbit:x3i9Uo_xfqRo8SW0Dfqrfw	final_qa	\N	Final QA	\N	\N	\N	\\x4a6a7874767342726b6376437874645168775a30657039534e41714f756e6f51334d4e4669794d324136673d	\\x5a4b56754b79415a556c647361586b6b77516d6964443436524a777a6a74414f642f544739694b546d54453d	\\x625a683274586444383737774c44396b787355634b2b43592f396d6f686d475257764365596b72593041383d	{}	http://localhost:3001/did:orbit:x3i9Uo_xfqRo8SW0Dfqrfw	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:39:46.455112+00	2026-06-21 16:39:46.455112+00	\N
did:orbit:_CFq89RS0H1Tq-zmss_tZg	e2e_user_1782060021	\N	E2E User	\N	\N	\N	\\x5633697166715441475343725433783171334b354b34646954447a7448664c555a7350437039456d4d41773d	\\x504d686d316e6f4139484d4f4a7634703167684d4e566c376a496b4563627256553744716c7255505248633d	\\x78723974777a56786654657863734669617a6e5a716a4c354a344c4c4d4f5a5172394d4533364b59332f6f3d	{}	http://localhost:3001/did:orbit:_CFq89RS0H1Tq-zmss_tZg	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:40:21.713732+00	2026-06-21 16:40:21.713732+00	\N
did:orbit:qz0XVo-Fv8xHzLjakDFOmg	e2e_user_1782060030	\N	E2E User	\N	\N	\N	\\x48647873717a467a3467387957617934647068766c4e6b566f68794f61746a69646d4d527a5232305545303d	\\x41595056612f4c364a2b497533514c4e766e306d3432596c4d466e4b33616575644f374938354147536e6f3d	\\x452f5a486857457834356a6571722b6c317669567a6936794b444b7446306c7363322f794f4345443937383d	{}	http://localhost:3001/did:orbit:qz0XVo-Fv8xHzLjakDFOmg	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:40:30.150268+00	2026-06-21 16:40:30.150268+00	\N
did:orbit:Vz84SICcvptxjrsW-XHmbA	e2e_target_1782060030	\N	E2E Target	\N	\N	\N	\\x53682f455a515262346f6465715657524667746c6357446768477370324b6b6468484d767a6151385378733d	\\x44783154387742766d6559586a78497063566d4f48334435352b79664376564737793964465a62776b456f3d	\\x2b43796634304e474a416777675142514c38767069776f57632f4c6e66456b66775063344e5576704c49593d	{}	http://localhost:3001/did:orbit:Vz84SICcvptxjrsW-XHmbA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 16:40:30.273602+00	2026-06-21 16:40:30.273602+00	\N
did:orbit:RlcpjbRjNwyAFmJpxxP7zg	qa_viewer	\N	QA Viewer	\N	\N	\N	\\x4667556a56735839733161363544316750564a32554d3249413444793230553645474663347a4d5a4474633d	\\x6b31524d3659624a48694d2b516c33734b536842384348532b6f672b3835316b784739447335712f7a68553d	\\x337a6f6353377767786636625554447438624b796271554a6377617656466d5572545636557546544f764d3d	{}	http://localhost:3001/did:orbit:RlcpjbRjNwyAFmJpxxP7zg	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:06:41.530669+00	2026-06-21 17:06:41.530669+00	\N
did:orbit:NegjcirB01pMnLRw-yKBuw	alice_demo	\N	Alice (Demo)	\N	\N	\N	\\x32436130336941777647374a466c4441766f49736b2f477a517439764638794e74566b58434b69526d52633d	\\x6f5235656d50756b36525a523542325238474a74674e495a374b6a503430736c4f59356a64534c72726a773d	\\x7a4f34573449526a44494d41416b71486d756d4f547242475261536b4975705158643532364453484b37343d	{}	http://localhost:3001/did:orbit:NegjcirB01pMnLRw-yKBuw	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:10:28.128113+00	2026-06-21 17:10:28.128113+00	\N
did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	bob_demo	\N	Bob (Demo)	\N	\N	\N	\\x6e676e4c323178304c2f55314d3647697841546249466d766930586e6259426f67557859566e625a2b53303d	\\x6d6b52517938472f4a6b7a75676c4d4e4656504b6531684b5a416263492b56366b2f61436d663936376e383d	\\x41424e456e784f54614d43787146534e3833745351664e68747239374b466c646b706848514f77524d446b3d	{}	http://localhost:3001/did:orbit:CMqvTcOJ7IcWGZDPJjXmDg	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:10:28.136802+00	2026-06-21 17:10:28.136802+00	\N
did:orbit:EBlHoJyllCnkfLnFbKqPpg	carol_demo	\N	Carol (Demo)	\N	\N	\N	\\x5443324175494a7145375966564c635551706453537a492b30637542776a3435347131506d3646467857343d	\\x74456637304944464b66745245664f4e693357432f54585871567546717264312b746a2b666a4c476841413d	\\x2b676934686e6f72764c46446173712b6c6f776f553644396e43797531387959617736596b32514436776f3d	{}	http://localhost:3001/did:orbit:EBlHoJyllCnkfLnFbKqPpg	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:10:28.142308+00	2026-06-21 17:10:28.142308+00	\N
did:orbit:AJs4_YVPMJGHdJ4ei3lVPA	alice_v2	\N	Alice	\N	\N	\N	\\x775361317a4c37616a384b5a447957533959394b536141385a3432775776617263504d664b6972434d30303d	\\x70574d747245784355676e3679354667743639746479594b726355794e5162516c444e305447714f6a53673d	\\x592f36396d596132723067394f7a2f52795439545958517043416761456257352f754376505a444e594a6b3d	{}	http://localhost:3001/did:orbit:AJs4_YVPMJGHdJ4ei3lVPA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:12:02.383573+00	2026-06-21 17:12:02.383573+00	\N
did:orbit:aqPQhIF-7kD5m24miWvzAA	alice_v3	\N	Alice	\N	\N	\N	\\x3658473745762f6546624d6544775a6d505653767677466656495441423149612f354f46344c2b42387a553d	\\x632b396a6249755a453734467a6b45393154655065355463505a39694d6d4735666d5643467874684e55343d	\\x43637a37705049456d734e745a336e465159476e3448617a464d66325659384930534a41344c63464338773d	{}	http://localhost:3001/did:orbit:aqPQhIF-7kD5m24miWvzAA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:13:23.052061+00	2026-06-21 17:13:23.052061+00	\N
did:orbit:k6iu5H6TWG_QsyHhQd2DPA	alice_v4	\N	Alice	\N	\N	\N	\\x3730586e505267564e627954415264774b694e355743703244656e4444454b41426d57775a2f724c69466f3d	\\x4a64706564516e544179746b4e4f6c70554e324e426b70317a6f3769715133366162526b634b6d457558343d	\\x3736316369576d487279622b56614e582f6e5a686f51416159697a4246734b54446f6e6d7136323942466b3d	{}	http://localhost:3001/did:orbit:k6iu5H6TWG_QsyHhQd2DPA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:13:37.137275+00	2026-06-21 17:13:37.137275+00	\N
did:orbit:MMFKhWkuds56_GxYncGr7w	alice_v5	\N	Alice	\N	\N	\N	\\x78773950625458737637612b307338474a58656c5170387650634f48644c6467722b5a2f64744f546d52343d	\\x6544636e694439592b70353254745758476e6b454541595241446279627255644c573053307a70376358513d	\\x496c485235763737573671694877533078303777444a4c622b58734e58613963534e7448302f35346d44343d	{}	http://localhost:3001/did:orbit:MMFKhWkuds56_GxYncGr7w	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:14:20.842249+00	2026-06-21 17:14:20.842249+00	\N
did:orbit:xSbg_lpi3EqJNf0NjM-VKA	alice_dbg	\N	Alice	\N	\N	\N	\\x6f746f69477567327968486a7836442b4c56683650655436684330477164753764634e6238794d745641493d	\\x5066396c614c58697343582b53766e55683650623154506d455977442f76364d4c354d44693453494430733d	\\x515433417956583058703852314b3355675648326a6e3758495a4f4e313630594b6778746e7170723339303d	{}	http://localhost:3001/did:orbit:xSbg_lpi3EqJNf0NjM-VKA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 17:14:58.787874+00	2026-06-21 17:14:58.787874+00	\N
did:orbit:FDvXpCq05uUb_GU-NGfYpQ	e2e_user_1782072562	\N	E2E User	\N	\N	\N	\\x4c674c665065476d327148656169634573412f3979475a53785453627a4358565353706e33626c386d4f633d	\\x625650507374686a77394d672b487572304b616e554e37315264625165414e4876766b62717873756642513d	\\x2b756a6c6e43523263496d6b6d3878304a3763696c46736c676e4c4a5442376649766a4a386879306f4b553d	{}	https://pds.orbit.com/did:orbit:FDvXpCq05uUb_GU-NGfYpQ	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 20:09:22.317052+00	2026-06-21 20:09:22.317052+00	\N
did:orbit:NKhHWv-Vz5aVHB50pX-wuA	e2e_target_1782072562	\N	E2E Target	\N	\N	\N	\\x352f78427378454c6457394e6c68446e393675723141704f6352305241523672315635704d7474765a4b6b3d	\\x3248663761356e7535316d706a4b454d61382f4f3743496555765635596a49634b79533335494d386955453d	\\x36666a57543778656d7a52662f61632b7648746c4d64584c4f4176435371424d5066552b6639792b7976513d	{}	https://pds.orbit.com/did:orbit:NKhHWv-Vz5aVHB50pX-wuA	\N	100	active	{"version": "orbit-v1", "registration": "webauthn"}	2026-06-21 20:09:22.414023+00	2026-06-21 20:09:22.414023+00	\N
\.


--
-- Name: events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."events_event_id_seq"', 1, false);


--
-- Name: groups_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."groups_group_id_seq"', 3, true);


--
-- Name: marketplace_listings_listing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."marketplace_listings_listing_id_seq"', 3, true);


--
-- Name: media_media_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."media_media_id_seq"', 1, false);


--
-- Name: messages_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."messages_message_id_seq"', 1, false);


--
-- Name: notifications_notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."notifications_notification_id_seq"', 1, false);


--
-- Name: orbit_streams_stream_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."orbit_streams_stream_id_seq"', 17, true);


--
-- Name: posts_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."posts_post_id_seq"', 14, true);


--
-- Name: reels_reel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."reels_reel_id_seq"', 3, true);


--
-- Name: reports_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."reports_report_id_seq"', 1, false);


--
-- Name: stories_story_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."stories_story_id_seq"', 1, true);


--
-- Name: threads_thread_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('"public"."threads_thread_id_seq"', 3, true);


--
-- Name: ai_agent_state ai_agent_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."ai_agent_state"
    ADD CONSTRAINT "ai_agent_state_pkey" PRIMARY KEY ("user_id");


--
-- Name: embeddings embeddings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."embeddings"
    ADD CONSTRAINT "embeddings_pkey" PRIMARY KEY ("entity_type", "entity_id");


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_pkey" PRIMARY KEY ("event_id");


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."follows"
    ADD CONSTRAINT "follows_pkey" PRIMARY KEY ("follower_id", "followee_id");


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."group_members"
    ADD CONSTRAINT "group_members_pkey" PRIMARY KEY ("group_id", "user_id");


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."groups"
    ADD CONSTRAINT "groups_pkey" PRIMARY KEY ("group_id");


--
-- Name: groups groups_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."groups"
    ADD CONSTRAINT "groups_slug_key" UNIQUE ("slug");


--
-- Name: marketplace_listings marketplace_listings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."marketplace_listings"
    ADD CONSTRAINT "marketplace_listings_pkey" PRIMARY KEY ("listing_id");


--
-- Name: media media_cid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."media"
    ADD CONSTRAINT "media_cid_key" UNIQUE ("cid");


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."media"
    ADD CONSTRAINT "media_pkey" PRIMARY KEY ("owner_id", "media_id");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("thread_id", "message_id");


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_pkey" PRIMARY KEY ("user_id", "notification_id");


--
-- Name: orbit_cache orbit_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orbit_cache"
    ADD CONSTRAINT "orbit_cache_pkey" PRIMARY KEY ("cache_key");


--
-- Name: orbit_streams orbit_streams_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."orbit_streams"
    ADD CONSTRAINT "orbit_streams_pkey" PRIMARY KEY ("stream_id");


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."posts"
    ADD CONSTRAINT "posts_pkey" PRIMARY KEY ("author_id", "post_id");


--
-- Name: reels reels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reels"
    ADD CONSTRAINT "reels_pkey" PRIMARY KEY ("author_id", "reel_id");


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reports"
    ADD CONSTRAINT "reports_pkey" PRIMARY KEY ("report_id");


--
-- Name: stories stories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."stories"
    ADD CONSTRAINT "stories_pkey" PRIMARY KEY ("author_id", "story_id");


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."subscriptions"
    ADD CONSTRAINT "subscriptions_pkey" PRIMARY KEY ("subscriber_id", "creator_id");


--
-- Name: threads threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."threads"
    ADD CONSTRAINT "threads_pkey" PRIMARY KEY ("thread_id");


--
-- Name: users users_handle_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_handle_key" UNIQUE ("handle");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("did");


--
-- Name: idx_cache_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_cache_expires" ON "public"."orbit_cache" USING "btree" ("expires_at") WHERE ("expires_at" IS NOT NULL);


--
-- Name: idx_embeddings_ann; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_embeddings_ann" ON "public"."embeddings" USING "hnsw" ("embedding" "public"."vector_cosine_ops");


--
-- Name: idx_events_geo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_events_geo" ON "public"."events" USING "gist" ("location_geo");


--
-- Name: idx_events_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_events_group" ON "public"."events" USING "btree" ("group_id", "starts_at");


--
-- Name: idx_events_starts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_events_starts" ON "public"."events" USING "btree" ("starts_at");


--
-- Name: idx_follows_close_friends; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_follows_close_friends" ON "public"."follows" USING "btree" ("followee_id") WHERE ("is_close_friend" = true);


--
-- Name: idx_follows_followee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_follows_followee" ON "public"."follows" USING "btree" ("followee_id", "created_at" DESC);


--
-- Name: idx_group_members_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_group_members_role" ON "public"."group_members" USING "btree" ("group_id", "role");


--
-- Name: idx_group_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_group_members_user" ON "public"."group_members" USING "btree" ("user_id");


--
-- Name: idx_groups_member_count; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_groups_member_count" ON "public"."groups" USING "btree" ("member_count" DESC);


--
-- Name: idx_groups_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_groups_search" ON "public"."groups" USING "gin" ("search_vector");


--
-- Name: idx_groups_topics; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_groups_topics" ON "public"."groups" USING "gin" ("topics");


--
-- Name: idx_marketplace_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_marketplace_category" ON "public"."marketplace_listings" USING "btree" ("category", "created_at" DESC);


--
-- Name: idx_marketplace_geo; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_marketplace_geo" ON "public"."marketplace_listings" USING "gist" ("location_geo");


--
-- Name: idx_marketplace_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_marketplace_search" ON "public"."marketplace_listings" USING "gin" ("search_vector");


--
-- Name: idx_marketplace_seller; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_marketplace_seller" ON "public"."marketplace_listings" USING "btree" ("seller_id", "created_at" DESC);


--
-- Name: idx_marketplace_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_marketplace_status" ON "public"."marketplace_listings" USING "btree" ("status", "created_at" DESC) WHERE ("status" = 0);


--
-- Name: idx_media_cid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_media_cid" ON "public"."media" USING "btree" ("cid");


--
-- Name: idx_media_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_media_type" ON "public"."media" USING "btree" ("media_type", "created_at" DESC);


--
-- Name: idx_messages_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_messages_created" ON "public"."messages" USING "btree" ("created_at" DESC);


--
-- Name: idx_messages_sender; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_messages_sender" ON "public"."messages" USING "btree" ("sender_id", "created_at" DESC);


--
-- Name: idx_messages_thread_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_messages_thread_created" ON "public"."messages" USING "btree" ("thread_id", "created_at" DESC);


--
-- Name: idx_notif_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_notif_actor" ON "public"."notifications" USING "btree" ("actor_id");


--
-- Name: idx_notif_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_notif_target" ON "public"."notifications" USING "btree" ("target_type", "target_id");


--
-- Name: idx_notif_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_notif_unread" ON "public"."notifications" USING "btree" ("user_id", "is_read", "ai_priority", "created_at" DESC) WHERE ("is_read" = false);


--
-- Name: idx_posts_author_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_author_created" ON "public"."posts" USING "btree" ("author_id", "created_at" DESC);


--
-- Name: idx_posts_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_created_at" ON "public"."posts" USING "btree" ("created_at" DESC);


--
-- Name: idx_posts_group_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_group_created" ON "public"."posts" USING "btree" ("group_id", "created_at" DESC) WHERE ("group_id" IS NOT NULL);


--
-- Name: idx_posts_hashtags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_hashtags" ON "public"."posts" USING "gin" ("hashtags");


--
-- Name: idx_posts_mentions; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_mentions" ON "public"."posts" USING "gin" ("mentions");


--
-- Name: idx_posts_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_pinned" ON "public"."posts" USING "btree" ("group_id", "created_at" DESC) WHERE ("is_pinned" = true);


--
-- Name: idx_posts_root; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_root" ON "public"."posts" USING "btree" ("root_id", "created_at") WHERE ("root_id" IS NOT NULL);


--
-- Name: idx_posts_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_posts_search" ON "public"."posts" USING "gin" ("search_vector");


--
-- Name: idx_reels_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_reels_created" ON "public"."reels" USING "btree" ("created_at" DESC);


--
-- Name: idx_reels_hashtags; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_reels_hashtags" ON "public"."reels" USING "gin" ("hashtags");


--
-- Name: idx_reels_search; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_reels_search" ON "public"."reels" USING "gin" ("search_vector");


--
-- Name: idx_reels_views; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_reels_views" ON "public"."reels" USING "btree" ("view_count" DESC) WHERE ("view_count" > 1000);


--
-- Name: idx_reports_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_reports_status" ON "public"."reports" USING "btree" ("status", "created_at" DESC);


--
-- Name: idx_reports_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_reports_target" ON "public"."reports" USING "btree" ("target_type", "target_id");


--
-- Name: idx_stories_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_stories_created" ON "public"."stories" USING "btree" ("created_at" DESC);


--
-- Name: idx_stories_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_stories_expires" ON "public"."stories" USING "btree" ("expires_at");


--
-- Name: idx_streams_channel; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_streams_channel" ON "public"."orbit_streams" USING "btree" ("channel", "created_at" DESC) WHERE ("processed" = false);


--
-- Name: idx_streams_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_streams_expires" ON "public"."orbit_streams" USING "btree" ("expires_at");


--
-- Name: idx_subs_creator; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_subs_creator" ON "public"."subscriptions" USING "btree" ("creator_id", "is_active", "started_at" DESC);


--
-- Name: idx_threads_1to1; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_threads_1to1" ON "public"."threads" USING "btree" ("participant_ids") WHERE ("thread_type" = 0);


--
-- Name: idx_threads_last_message; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_threads_last_message" ON "public"."threads" USING "btree" ("last_message_at" DESC);


--
-- Name: idx_threads_participants; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_threads_participants" ON "public"."threads" USING "gin" ("participant_ids");


--
-- Name: idx_users_display_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_users_display_name_trgm" ON "public"."users" USING "gin" ("display_name" "public"."gin_trgm_ops");


--
-- Name: idx_users_domain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_users_domain" ON "public"."users" USING "btree" ("domain") WHERE ("domain" IS NOT NULL);


--
-- Name: idx_users_handle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_users_handle" ON "public"."users" USING "btree" ("handle");


--
-- Name: idx_users_metadata_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_users_metadata_gin" ON "public"."users" USING "gin" ("metadata");


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_users_status" ON "public"."users" USING "btree" ("status", "created_at" DESC);


--
-- Name: idx_users_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "idx_users_updated_at" ON "public"."users" USING "btree" ("updated_at" DESC);


--
-- Name: posts posts_search_vector_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "posts_search_vector_trigger" BEFORE INSERT OR UPDATE OF "content_text", "hashtags" ON "public"."posts" FOR EACH ROW EXECUTE FUNCTION "public"."posts_search_vector_update"();


--
-- Name: reels reels_search_vector_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER "reels_search_vector_update" BEFORE INSERT OR UPDATE OF "caption", "hashtags" ON "public"."reels" FOR EACH ROW EXECUTE FUNCTION "public"."reels_search_vector_update"();


--
-- Name: ai_agent_state ai_agent_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."ai_agent_state"
    ADD CONSTRAINT "ai_agent_state_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: events events_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_creator_id_fkey" FOREIGN KEY ("creator_id") REFERENCES "public"."users"("did");


--
-- Name: events events_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_group_id_fkey" FOREIGN KEY ("group_id") REFERENCES "public"."groups"("group_id") ON DELETE CASCADE;


--
-- Name: follows follows_followee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."follows"
    ADD CONSTRAINT "follows_followee_id_fkey" FOREIGN KEY ("followee_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: follows follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."follows"
    ADD CONSTRAINT "follows_follower_id_fkey" FOREIGN KEY ("follower_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: group_members group_members_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."group_members"
    ADD CONSTRAINT "group_members_group_id_fkey" FOREIGN KEY ("group_id") REFERENCES "public"."groups"("group_id") ON DELETE CASCADE;


--
-- Name: group_members group_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."group_members"
    ADD CONSTRAINT "group_members_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: groups groups_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."groups"
    ADD CONSTRAINT "groups_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."users"("did");


--
-- Name: marketplace_listings marketplace_listings_seller_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."marketplace_listings"
    ADD CONSTRAINT "marketplace_listings_seller_id_fkey" FOREIGN KEY ("seller_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: media media_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."media"
    ADD CONSTRAINT "media_owner_id_fkey" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."messages"
    ADD CONSTRAINT "messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "public"."users"("did");


--
-- Name: messages messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."messages"
    ADD CONSTRAINT "messages_thread_id_fkey" FOREIGN KEY ("thread_id") REFERENCES "public"."threads"("thread_id") ON DELETE CASCADE;


--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_actor_id_fkey" FOREIGN KEY ("actor_id") REFERENCES "public"."users"("did");


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."notifications"
    ADD CONSTRAINT "notifications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: posts posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."posts"
    ADD CONSTRAINT "posts_author_id_fkey" FOREIGN KEY ("author_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: reels reels_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reels"
    ADD CONSTRAINT "reels_author_id_fkey" FOREIGN KEY ("author_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: reports reports_reporter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reports"
    ADD CONSTRAINT "reports_reporter_id_fkey" FOREIGN KEY ("reporter_id") REFERENCES "public"."users"("did");


--
-- Name: reports reports_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."reports"
    ADD CONSTRAINT "reports_reviewed_by_fkey" FOREIGN KEY ("reviewed_by") REFERENCES "public"."users"("did");


--
-- Name: stories stories_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."stories"
    ADD CONSTRAINT "stories_author_id_fkey" FOREIGN KEY ("author_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."subscriptions"
    ADD CONSTRAINT "subscriptions_creator_id_fkey" FOREIGN KEY ("creator_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_subscriber_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."subscriptions"
    ADD CONSTRAINT "subscriptions_subscriber_id_fkey" FOREIGN KEY ("subscriber_id") REFERENCES "public"."users"("did") ON DELETE CASCADE;


--
-- Name: threads threads_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY "public"."threads"
    ADD CONSTRAINT "threads_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."users"("did");


--
-- PostgreSQL database dump complete
--

\unrestrict O1JiZAIPfMaO3rbgxEWLx1c4QFnjU1vLahCTw5kwL9WmI3qr263AuLf1Dv2Y8TZ

